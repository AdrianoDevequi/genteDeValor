<?php
require_once dirname(__FILE__) . '/Controller/PessoaController.php';
include '_msg.php';
$objcontroller = new PessoaController();
$dados = $objcontroller->CarregarDados();
$nome_usuario = '';
if(isset($_POST['btn_finalizar'])){
    $nome_usuario = $_POST['nome_usuario'];
    $login_pessoa = $_POST['login_usuario'];
    $senha_pessoa = $_POST['senha_usuario'];
    $ret = $objcontroller->criarConta($nome_usuario, $login_pessoa, $senha_pessoa);
}

?>
<!DOCTYPE html>
<html dir="ltr" lang="pt-BR">
<head>
    <?php include '_head.php'; ?>
</head>
<?php require_once '_menu.php'; ?>
<body>
<div class="container">
    <form method="post" action="?">
        <?php echo RetornaMsg($ret); ?>
        <div class="mb-3">
            <label class="form-label">Nome do Usuário</label>
            <input type="text" class="form-control" id="nome_usuario" name="nome_usuario" placeholder="nome">
            <label class="form-label">Login</label>
            <input type="text" class="form-control" id="login_usuario" name="login_usuario" placeholder="Login">
            <label class="form-label">Senha</label>
            <input type="text" class="form-control" id="senha_usuario" name="senha_usuario" placeholder="Senha">
            <br/>
            <button class="btn btn-success" id = "btn_finalizar" name ="btn_finalizar" > Finalizar</button >
        </div>
    </form>
</div>
</body>
