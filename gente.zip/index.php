<?php
 require_once 'Controller/PessoaController.php';
 include '_msg.php';

   $objcontroller = new PessoaController();
   $dados = $objcontroller->CarregarDados();
   $votos_logado = $objcontroller->buscaQtdVotos();

   $ret = '';
   $_GET['action'] = '';
   $categoria_voto = '';

if(isset($_POST['btn_votar'])){
    $id_pessoa = $_POST['id_pessoa'];
    $id_categoria_pessoa = $_POST['id_categoria_pessoa'];
    $ret = $objcontroller->adicionarVoto($id_pessoa, $id_categoria_pessoa);
    echo '<script>window.location = "https://gentedevalor.agenciamango.com.br/site/sucesso.php";</script>';
}
UtilController::VerificarLogado();
?>
<!DOCTYPE html>
<html dir="ltr" lang="pt-BR">
<head>
    <?php include '_head.php'; ?>
</head>
    <?php require_once '_menu.php'; ?>
<body>
<div class="container">
<br>
<?php
    if(isset($_GET['cat'])){
        for($i =0; $i < count($dados); $i++){
        if($_GET['cat'] == 1 && $dados[$i]['tb_categoria_id_categoria'] == 1) {

            $votos_categoria = $objcontroller->buscaQtdVotosMesmaCategoria(1);
            include 'view/elements/lista-pessoa.php';
        }
        if($_GET['cat'] == 2 && $dados[$i]['tb_categoria_id_categoria'] == 2){

            $votos_categoria = $objcontroller->buscaQtdVotosMesmaCategoria(2);
            include 'view/elements/lista-pessoa.php';

        }if($_GET['cat'] == 3 && $dados[$i]['tb_categoria_id_categoria'] == 3){

            $votos_categoria = $objcontroller->buscaQtdVotosMesmaCategoria(3);
            include 'view/elements/lista-pessoa.php';

        }if($_GET['cat'] == 4 && $dados[$i]['tb_categoria_id_categoria'] == 4){

            $votos_categoria = $objcontroller->buscaQtdVotosMesmaCategoria(4);
            include 'view/elements/lista-pessoa.php';
             }
        }
    } ?>

<script>
    $('#cat1').one('submit', function() {
        $(this).find('input[type="submit"]').attr('disabled', 'disabled');
    });
</script>
</div>
</body>
</html>
