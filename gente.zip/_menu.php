<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="#">Logo</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                <a class="nav-link" href="https://gentedevalor.agenciamango.com.br/?cat=1">Fazer Acontecer</a>
                <a class="nav-link" href="https://gentedevalor.agenciamango.com.br/?cat=2">Cria Simplicidade</a>
                <a class="nav-link" href="https://gentedevalor.agenciamango.com.br/?cat=3">Fortalecer Pessoas</a>
                <a class="nav-link" href="https://gentedevalor.agenciamango.com.br/?cat=4">Paixão</a>
                <a class="nav-link" href="http://gentedevalor.agenciamango.com.br/cadastro.php">Cadastro</a>
                <form method="POST" action="">
                    <input type="submit" name="deslogar" class="btn btn-link" value="Deslogar">
                </form>

            </div>
        </div>
    </div>
</nav>