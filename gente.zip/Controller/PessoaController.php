<?php
require_once 'DAO/PessoaDAO.php';
//require_once '/home/wmbar465/public_html/doapet.com.br/Class/class.phpmailer.php';
require_once 'UtilController.php';

class PessoaController {

    public function adicionarVoto($id_pessoa, $id_categoria_pessoa)
    {
        $voto = 1;

        $objdao = new PessoaDAO();

        $usuario_logado = UtilController::RetornarCodigoLogado();

        $objdao->adicionarVoto($id_pessoa, $voto, $usuario_logado, $id_categoria_pessoa);
    }

    public function criarConta($nome_pessoa, $login_pessoa, $senha_pessoa) {

        $nome_pessoa = UtilController::TratarString($nome_pessoa);

        //$email_pessoa = UtilController::TratarString($email_pessoa);
        //$senha_pessoa = UtilController::TratarString($senha_pessoa);
        //$repetir_senha = UtilController::TratarString($repetir_senha);

        //$telefone_pessoa = UtilController::TirarCaracteresEspeciais($telefone_pessoa);

        if (trim($nome_pessoa) == "" ) {

            return 0;
        }

        if (trim(strlen($nome_pessoa)) < 8) {

            return -1;
        }

        try {

            $objdao = new PessoaDAO();

            $categoria = 1;



            $id = $objdao->criarConta($nome_pessoa, $categoria, $login_pessoa, $senha_pessoa);


        } catch (Exception $ex) {

            echo $ex->getMessage();

            return -100;
        }
    }

    public function CarregarDados() {

        $objController = new PessoaDAO();

        //$cod_pessoa = UtilController::RetornarCodigoLogado();

        return $objController->carregarDados();
    }

    public function buscaQtdVotos() {

        $objController = new PessoaDAO();

        return $objController->buscaQtdVotos();
    }

    public function buscaQtdVotosMesmaCategoria($categoria_voto) {

        $objController = new PessoaDAO();

        $usuario_logado = UtilController::RetornarCodigoLogado();

        return $objController->buscaQtdVotosMesmaCategoria($usuario_logado, $categoria_voto);
    }

    public function CarregarVotos($id_pessoa) {

        $objController = new PessoaDAO();

        //$cod_pessoa = UtilController::RetornarCodigoLogado();

        return $objController->CarregarVotos($id_pessoa);
    }

    public function ValidarLogin($email, $senha) {

        if (trim($email) == '' || trim($senha) == '') {

            return 0;
        }

        $dao = new PessoaDAO();

        $usuario = $dao->ValidarLogin($email);

        if (count($usuario) == 0) {
            return -7;
        } else {

            // Criptografa a senha digitada para ser comparada com a criptografia do banco
            //$senha = password_hash($senha, PASSWORD_DEFAULT);

            if ($senha == $usuario[0]['senha_pessoa']){

                UtilController::GuardarInformacao($usuario[0]['id_pessoa']);

                //header('location: ver_anuncios.php');
                echo '<script>window.location = "https://gentedevalor.agenciamango.com.br/";</script>';
            } else {
                return -8;
            }
        }
    }

    public function ValidaEmail($email) {
        if (trim($email) == '') {
            return 0;
        }try {
            $objDao = new PessoaDAO();
            return $objDao->ValidaEmail($email);
        } catch (Exception $ex) {
            return -100;
        }
    }
}
