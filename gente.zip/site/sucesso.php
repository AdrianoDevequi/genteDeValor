<!DOCTYPE html>
<html dir="ltr" lang="pt-BR">
<head>
   <?php include dirname(__FILE__).'/../_head.php'; ?>
</head>
<?php include dirname(__FILE__).'/../_menu.php'; ?>
<body>
<div class="container">
    <br/>
    <h2>Voto Registrado com sucesso!</h2>
</div>
</body>
