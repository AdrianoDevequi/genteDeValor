<form method="post" action="" id="cat1">
    <?php $votos = $objcontroller->CarregarVotos($dados[$i]['id_pessoa']) ?>
    <input type="hidden" name="id_pessoa" value="<?= $dados[$i]['id_pessoa']; ?>">
    <input type="hidden" name="id_categoria_pessoa" value="<?= $dados[$i]['tb_categoria_id_categoria']; ?>">
    <div class="card">
        <div class="card-body">
            <?php echo $dados[$i]['nome_pessoa'] ?><br/>
            <?php if($votos[0]['total_votos'] > 0){
                echo 'Quantidade de votos: ' . $votos[0]['total_votos'];
            }else{
                echo 'Quantidade de votos: 0';
            } ?><br/>

            <?php
            if($votos_logado[0]['total_votos_logado'] <= 20 && $votos_categoria[0]['total_votos_categoria'] <= 10) { ?>
                <input type="submit" class="btn btn-success" id="btn_finalizar" name="btn_votar">
            <?php }else{ ?>
                <input type="submit" class="btn btn-success" disabled>
            <?php } ?>
        </div>
    </div>
</form>
<br/>